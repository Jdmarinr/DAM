package prog_ut4y5_ejercicio1;

import java.time.LocalDate;

/**
 *
 * @author jdmarin
 */
public class RegistroVentasDiaria {

    private LocalDate fecha;
    private double[] listaVentas;
    private int[] listCodProducto;

    public RegistroVentasDiaria(LocalDate _fecha, double[] _listaVentas, int[] _listCodProducto) {
        fecha = _fecha;
        listaVentas = _listaVentas;
        listCodProducto = _listCodProducto;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate _fecha) {
        fecha = _fecha;
    }

    public void imprimirRegistroVentas() {
        System.out.println("Fecha: " + fecha + "\n");
        for (int i = 0; i < listaVentas.length; i++) {
            System.out.println("Cod. " + listCodProducto[i]);
            System.out.println("Precio: " + listaVentas[i] + "\n");
        }
    }

    public double calcularMaximo() {
        double max = 0;
        for (int i = 0; i < listaVentas.length; i++) {
            if (max < listaVentas[i]) {
                max = listaVentas[i];
            }
        }
        return max;
    }

    public void calcularProductoEstrella() {
        double sumaValor = 0;
        int num_mas_usado;
        int veces[] = new int[listCodProducto.length];
        int posicion = 0;

        for (int i = 0; i < listCodProducto.length; i++) {
            num_mas_usado = listCodProducto[i];
            for (int j = i; j < listCodProducto.length; j++) {
                if (listCodProducto[j] == num_mas_usado) {
                    veces[i]++;
                }
            }
        }

        num_mas_usado = 0;
        for (int k = 0; k < veces.length; k++) {
            if (num_mas_usado < veces[k]) {
                num_mas_usado = veces[k];
                posicion = k;
            }
        }

        for (int i = 0; i < listCodProducto.length; i++) {
            if (listCodProducto[i] == listCodProducto[posicion]) {
                sumaValor += listaVentas[i];
            }

        }
        System.out.println("El producto estrella tiene el código " + listCodProducto[posicion] + " y su valor es " + sumaValor);

    }

}
