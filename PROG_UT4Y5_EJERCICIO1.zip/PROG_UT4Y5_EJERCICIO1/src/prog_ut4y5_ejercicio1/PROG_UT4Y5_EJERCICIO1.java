package prog_ut4y5_ejercicio1;

import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author jdmarin
 */
public class PROG_UT4Y5_EJERCICIO1 {

    public static void main(String[] args) {

        double arrayVentas[] = {500.25, 100.50, 17.75, 250.50, 500.50, 10.60};
        int arrayCodProducto[] = {4, 2, 3, 3, 4, 4};
        LocalDate fecha = LocalDate.of(2019, Month.FEBRUARY, 03);
        
        RegistroVentasDiaria registroVentaLunes = new RegistroVentasDiaria(fecha, arrayVentas, arrayCodProducto);

        registroVentaLunes.imprimirRegistroVentas();
        
        fecha = LocalDate.of(2019, Month.FEBRUARY, 04);
        
        registroVentaLunes.setFecha(fecha);
        
        registroVentaLunes.imprimirRegistroVentas();
        
        System.out.println("El máximo de ventas es: " + registroVentaLunes.calcularMaximo());
        
        registroVentaLunes.calcularProductoEstrella();
    }

}
