package tema05e6;

/**
 *
 * @author Aritz y Juan David
 */
public class Test {

    public static void main(String[] args) {

        Descarga descarga1 = new Descarga("Manual de programación", 255, 10);
        Descarga descarga2 = new Descarga("Manual de Lenguaje", 200, 10);
        Descarga descarga3 = new Descarga("Manual de BBDD", 120, 15);

        System.out.println("\t---Archivo 1---");
        System.out.println("Nombre del archivo: " + descarga1.getNombreDescarga());
        System.out.println("Tamaño del archivo: " + descarga1.getTamañoDescarga() + "MB");
        System.out.println("Velocidad de descarga: " + descarga1.getVelocidadDescarga() + " Megabites\n");

        System.out.println("\t---Archivo 2---");
        System.out.println("Nombre del archivo: " + descarga2.getNombreDescarga());
        System.out.println("Tamaño del archivo: " + descarga2.getTamañoDescarga() + "MB");
        System.out.println("Velocidad de descarga: " + descarga2.getVelocidadDescarga() + " Megabites\n");

        System.out.println("\t---Archivo 3---");
        System.out.println("Nombre del archivo: " + descarga3.getNombreDescarga());
        System.out.println("Tamaño del archivo: " + descarga3.getTamañoDescarga() + "MB");
        System.out.println("Velocidad de descarga: " + descarga3.getVelocidadDescarga() + " Megabites\n");

        mostrarDatos(descarga1);
        mostrarDatos(descarga2);
        mostrarDatos(descarga3.getNombreDescarga(), descarga3.getTamañoDescarga(), descarga3.getVelocidadDescarga());

    }

    public static void mostrarDatos(Descarga desc) {
        desc.getNombreDescarga();
        desc.getTamañoDescarga();
        desc.getVelocidadDescarga();

        double tiempoDescarga;
        int hora;
        int min;
        int seg;

        tiempoDescarga = desc.getTamañoDescarga() * 8 / (desc.getVelocidadDescarga());
        hora = (int) tiempoDescarga / 3600;
        min = (int) (tiempoDescarga - (3600 * hora)) / 60;
        seg = (int) tiempoDescarga - ((hora * 3600) + (min * 60));

        System.out.println("El archivo " + desc.getNombreDescarga() + " tardará en descargarse " + hora + " horas " + min + " minutos y " + seg + " segundos.");

    }

    public static void mostrarDatos(String nombreDescarga, int tamaño, double velocidad) {
        double tiempoDescarga;
        int hora;
        int min;
        int seg;

        tiempoDescarga = tamaño * 8 / (velocidad);
        hora = (int) tiempoDescarga / 3600;
        min = (int) (tiempoDescarga - (3600 * hora)) / 60;
        seg = (int) tiempoDescarga - ((hora * 3600) + (min * 60));

        System.out.println("El archivo " + nombreDescarga + " tardará en descargarse " + hora + " horas " + min + " minutos y " + seg + " segundos.");
    }

}
