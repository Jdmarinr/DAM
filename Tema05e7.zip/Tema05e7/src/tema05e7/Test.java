/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema05e7;

import java.util.Scanner;

/**
 *
 * @author Aritz y Juan David
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        crearDescarga();
    }

    public static void crearDescarga() {
        boolean aux = false;
        char aux1;
        while (aux == false) {
            
            Scanner sc = new Scanner(System.in);
            
            System.out.println("Introduzca el nombre del archivo: ");
            String nombre = sc.next();
            System.out.println("Introduzca el tamaño del archivo en MB: ");
            int tamaño = sc.nextInt();
            System.out.println("Introduzca la velocidad de su ADSL en megabits: ");
            double velocidad = sc.nextDouble();
            
            Descarga desc = new Descarga(nombre, tamaño, velocidad);
            
            mostrarDatos(desc);
            
            System.out.println("¿Quiere calcular otra descarga? (Y/N)");
            aux1 = sc.next().charAt(0);
            if(aux1 == 'N'){
                aux = true;
            }
        }
    }

    public static void mostrarDatos(Descarga desc) {
        desc.getNombreDescarga();
        desc.getTamañoDescarga();
        desc.getVelocidadDescarga();

        double tiempoDescarga;
        int hora;
        int min;
        int seg;

        tiempoDescarga = desc.getTamañoDescarga() * 8 / (desc.getVelocidadDescarga());
        System.out.println(tiempoDescarga);
        hora = (int) tiempoDescarga / 3600;
        min = (int) (tiempoDescarga - (3600 * hora)) / 60;
        seg = (int) tiempoDescarga - ((hora * 3600) + (min * 60));

        System.out.println("El archivo " + desc.getNombreDescarga() + " tardará en descargarse " + hora + " horas " + min + " minutos y " + seg + " segundos.");

    }
}
