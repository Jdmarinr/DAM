/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tema05e7;

/**
 *
 * @author Aritz y Juan David
 */
public class Descarga {
    private String nombreDescarga;
    private int tamañoDescarga;
    private double velocidadDescarga;

    public Descarga(String _nombreDescarga, int _tamañoDescarga, double _velocidadDescarga) {
        nombreDescarga = _nombreDescarga;
        tamañoDescarga = _tamañoDescarga;
        velocidadDescarga = _velocidadDescarga;
    }

    public String getNombreDescarga() {
        return nombreDescarga;
    }

    public int getTamañoDescarga() {
        return tamañoDescarga;
    }

    public double getVelocidadDescarga() {
        return velocidadDescarga;
    }
}
